import json
import requests

predictionUrl="YOUR_PREDICTION_URL"
predictionKey = "YOUR_PREDITION_KEY"
img = "https://github.com/MicrosoftLearning/AI-900-AIFundamentals/raw/main/data/vision/road-safety/road-safety-$($img_num).jpg"

data = {
    "Prediction-Key": "fa79eabca38c491486b40514e1f4dca1",
    "Content-Type": "application/json",
}

body = {'url' : img }


print("Analyzing image...\n")
response = requests.post(predictionUrl, headers=data, json=body)
result = response.json()

predictions = result["predictions"]

for item in predictions:
    if item["probability"] > 0.6:
        print(item["tagName"] + " (" + str(item["probability"]) + "%)")
        print(item["boundingBox"], "\n")