import requests
import json

# URL a la que deseas realizar la solicitud POST
img ="https://img.freepik.com/vector-gratis/lindo-personaje-dibujos-animados-perro-sentado_1308-135528.jpg"
predictionUrl="https://anlisistextov2.cognitiveservices.azure.com/customvision/v3.0/Prediction/2ed9fc82-7fd7-4caa-aa2a-706ff7201143/classify/iterations/Clasificador/url"
body = {'url': img}

body_string = json.dumps(body)

# Datos que deseas enviar en el cuerpo de la solicitud (puede ser un diccionario)
data = {
    'Prediction-Key': 'd876a5f5153b415daad195249dc49e4b',
    'Content-Type': 'application/json',
    'Body': body_string
}

# Realiza la solicitud POST
response = requests.post(predictionUrl, json=body, headers=data)

# Verifica la respuesta
if response.status_code == 200:
    # La solicitud fue exitosa, puedes procesar la respuesta aquí
    print("Solicitud exitosa")
    print(response.json())
else:
    # Hubo un error en la solicitud
    print(f"Error: {response.status_code}")
    print(response.text)

#Otra cosa de probabilidad jajajajajaja
response = requests.post(predictionUrl, json=body, headers=data)
response_data = response.json()
predictions = response_data.get('predictions', [])
for prediction in predictions:
    probability = prediction.get('probability', 0.0)  # Obtén la probabilidad
    tag_name = prediction.get('tagName', 'Desconocido')
    if((probability*100)>70):
        print(f"Probabilidad: {probability}")
        print(f"Etiqueta: {tag_name}")